import React from "react";
import './Css/Home.css'
import Navbar from "./Navbar";



export default function Homepage() {


    return <>
        <div className="clr">
            <div className="container1">
                <h1 className="rftes">
                    <span className="text" style={{'--light':1}}>R</span>
                    <span className="text1" style={{'--light':2}}>F</span>
                    <span className="text2" style={{'--light':3}}>T</span>
                    <span className="text3" style={{'--light':4}}>E</span>
                    <span className="text4" style={{'--light':5}}>S</span>
                </h1>
                <div>
                    <i className="fa-solid fa-user user"></i>

                </div>
                <p className="login">Log in</p>



                <Navbar></Navbar>
            </div>
        </div>




    </>

}