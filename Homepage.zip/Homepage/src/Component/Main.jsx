import React from "react";
import './Css/main.css'
import news from './Images/bg1.jpg';

export default function Main(props) {

    var a = new Date();

    //  var b=a.getDate()+(a.getMonth()+1)
    var dt = a.toDateString()

    return (
        <>
            <div className="date">
                <h2 className="wel"> Welcome to RFTES.com</h2>
                <h2 className="dt">{dt}</h2>

            </div>
             {/* <div className="fcontainer">
             <div className="first">
             <img  className="card" src={news} alt="This pitcure is unaviavble"></img>
             <p className="para">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit, optio Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore voluptatem consequuntur fugit sequi qui dolorem reiciendis, provident numquam reprehenderit omnis?</p>
             </div>
            
                <div className="second">
                <img  className="card1" src={news} alt="This pitcure is unaviavble"></img>
                <p className="para1">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Optio neque ea consequatur asperiores quo, ipsam in doloremque blanditiis ullam deserunt.</p>
                </div>
                <div>3</div>
                <div>4</div>
                <div>5</div>
                </div>
             */}
        </>
    )
}