import React from "react";
import './Css/signup.css';
import news from './Images/bg1.jpg';

export default function Signup() {

    return <>
        <div className="flex">
            <div className="container" >

                <span className="text" style={{ '--wave': 1 }} >R</span>
                <span className="text1" style={{ '--wave': 2 }} >F</span>
                <span className="text1" style={{ '--wave': 3 }} >T</span>
                <span className="text1" style={{ '--wave': 4 }} >E</span>
                <span className="text1" style={{ '--wave': 5 }}> S</span>
                <div>
                    <br></br>
                    <br></br>
                    <br></br>
                    <p className="sign">Sign Up</p>
                </div>



            </div>

            <div>
            <img src={news} alt="This Photo is unavailable">   </img>
            </div>
         
        </div>
        


    </>
}



